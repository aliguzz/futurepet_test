defmodule Gittask.LayoutViewTest do
  use Gittask.ConnCase, async: true
end
