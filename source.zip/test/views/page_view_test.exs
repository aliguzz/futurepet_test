defmodule Gittask.PageViewTest do
  use Gittask.ConnCase, async: true
end
