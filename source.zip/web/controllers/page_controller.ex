defmodule Gittask.PageController do
  use Gittask.Web, :controller

  def index(conn, _params) do
    username = _params["username"]
    submitted = if username, do: true, else: false
    found = false
    message = "User Not Found"
    user = ""
    repos = ""

    if submitted do
      url = "https://api.github.com/users/#{username}"
      response = HTTPoison.get!(url)
      user_data = Poison.decode!(response.body)
      found = if user_data["message"], do: false, else: true
      user = if found, do: user_data, else: ""
      message = if found, do: "User Found", else: "User Not Found"
      repos =
        if found do
          repo_url = "https://api.github.com/users/#{username}/repos"
          response = HTTPoison.get!(repo_url)
          repos = Poison.decode!(response.body)    
        end
      render conn, "index.html", user: user, found: found, message: message, repos: repos, username: username, submitted: submitted
    else
      render conn, "index.html", user: user, found: found, message: message, repos: repos, username: username, submitted: submitted  
    end
    
  end
end
