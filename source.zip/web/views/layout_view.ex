defmodule Gittask.LayoutView do
  use Gittask.Web, :view
end
