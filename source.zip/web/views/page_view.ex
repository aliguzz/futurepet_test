defmodule Gittask.PageView do
  use Gittask.Web, :view
end
