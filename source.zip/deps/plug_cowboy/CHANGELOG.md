# Changelog

## v1.0.0

Extract `Plug.Adapters.Cowboy2` from Plug into `Plug.Cowboy.Adapter`
